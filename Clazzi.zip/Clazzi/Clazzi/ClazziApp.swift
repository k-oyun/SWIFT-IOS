//
//  ClazziApp.swift
//  Clazzi
//
//  Created by Admin on 8/26/25.
//

import SwiftUI

@main
struct ClazziApp: App {
    var body: some Scene {
        WindowGroup {
            VoteListView()
        }
    }
}
